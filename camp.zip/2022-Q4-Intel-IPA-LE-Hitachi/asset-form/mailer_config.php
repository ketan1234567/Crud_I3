<?
//error_reporting(E_STRICT);

//date_default_timezone_set('America/Toronto');

require_once('phpmailer5/class.phpmailer.php');

$mail = new PHPMailer();


$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host = "";
$mail->SMTPAuth = true; // enable SMTP authentication
$mail->SMTPKeepAlive = true; // SMTP connection will not close after each email sent
//$mail->SMTPSecure = "ssl"; // sets the prefix to the servier
$mail->Host = "smtp.critsend.com"; // sets GMAIL as the SMTP server
$mail->Port = 587;
$mail->Mailer = "smtp";
//error_reporting(E_ALL);
$mail->Username = "Rachel@ithirings.com"; // SMTP account username
$mail->Password = "rachel@123"; // SMTP account password


?>
