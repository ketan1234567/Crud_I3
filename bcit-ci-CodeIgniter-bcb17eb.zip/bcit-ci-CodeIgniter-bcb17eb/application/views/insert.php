<!DOCTYPE html>
<html>

<head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<title>

	</title>
	<style>
		form{
			border: 1px solid gray;
			border-radius: 5px;
			box-shadow: 0px 0px 15px 5px gray;
			padding: 20px;
		}
	</style>
</head>

<body>
	<div class="container mt-5">
		<div class="row">
			<div class="col-sm-12">
				<form method="post" action="<?php echo base_url('Crud/savedata') ?>" enctype="multipart/form-data">
					<div class="form-group">
						<label for="exampleInputEmail1">Name</label>
						<input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="name">

					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Email</label>
						<input type="email" class="form-control" name="email" id="exampleInputPassword1" placeholder="Password">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Phone</label>
						<input type="text" class="form-control" id="exampleInputPassword1" placeholder="phone" name="mobile">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Address</label>
						<input type="text" class="form-control" id="exampleInputPassword1" placeholder="address" name="address">
					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">file</label>
						<input type="file" class="form-control" name="file" multiple>
					</div>

					<button type="submit" name="save" class="btn btn-primary">Submit</button>
					<a class="btn btn-success" href="<?php echo base_url('Crud/displaydata')  ?>">All Record</a>

				</form>

			</div>
			<div class="row mt-5">
				<div class="col-sm-12 ml-5">
					<table width="600" border="0" cellspacing="5" cellpadding="5">
						<tr style="background:#CCC">
							<th>Sr No</th>
							<th>Name</th>
							<th>Email</th>
							<th>Phone</th>
							<th>Address</th>
							<th>images</th>
							<th>Actions</th>
						</tr>
						<?php
						$i = 1;
						for ($j = 0; $j < count($data); $j++) {
						?>

							<tr>
								<td><?php echo $i; ?></td>
								<td><?php echo $data[$j]['name'] ?></td>
								<td><?php echo $data[$j]['email'] ?></td>
								<td><?php echo $data[$j]['mobile'] ?></td>
								<td><?php echo $data[$j]['address'] ?></td>
							   <td> <a class="btn btn-info btn-xs"href="<?php echo base_url('Crud/deletedata/'.$data[$j]['id']) ?>">delete</a> </td>
							   <td> <a class="btn btn-info btn-xs"href="<?php echo base_url('Crud/updatedata/'.$data[$j]['id']) ?>">update</a> </td>
							


							</tr>

						<?php
						$i++;
						}
						?>
					</table>
				</div>


			</div>

		</div>
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>