<?php
class Crud extends CI_Controller
{
	public function __construct()
	{
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load database libray manually*/
		$this->load->database();

		/*load Model*/
		$this->load->model('Crud_model');
	}
	/*Insert*/
	public function savedata()
	{
		/*load registration view form*/
		//$this->load->view('insert');

		/*Check submit button */
		$name = $_FILES['file']['name'];
		$uploads_dir = 'upload/';
		$tmp_name = $_FILES["file"]["tmp_name"];

		move_uploaded_file($tmp_name, "$uploads_dir/$name");

		$data = array(
			'name' => $this->input->post('name'),
			'email' => $this->input->post('email'),
			'mobile' => $this->input->post('mobile'),
			'address' => $this->input->post('address'),
			'file' => $name

		);
		$response = $this->Crud_model->saverecords($data);
		if ($response == true) {
			redirect('insert');
		}
	}

	public function displaydata()
	{

		$result['data'] = $this->Crud_model->displaydata();
		//   print_r($result);
		$this->load->view('display_records', $result);
	}

	public function deletedata($id)
	{


		$response = $this->Crud_model->deleterecords($id);
		if ($response == true) {
			echo '<script>
	alert("data Deleted");
	<a href="Crud/insert">
	</a>
	      </script>';
		}
	}
	public function updatedata($id)
	{
	
		$result['data'] = $this->Crud_model->update_records($id);
		//print_r($result);

		$this->load->view('update_records', $result);


		// if ($this->input->post('update')) {
		// 	$name = $this->input->post('name');
		// 	$email = $this->input->post('email');
		// 	$mobile = $this->input->post('mobile');
		// 	$address = $this->input->post('address');
		// 	$this->Crud_model->update_records($name, $email, $mobile, $address);
		// 	echo "Date updated successfully !";
		// }
	}
}
