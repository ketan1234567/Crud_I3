<?php
class Crud_model extends CI_Model 
{
	
	function saverecords($data)
	{
		
        $this->db->insert('student',$data);
        return true;
	}
	function displaydata()
	{
		
		$query = $this->db->get('student')->result_array();
	//   $query=$this->db->get("student");
	  return $query;
	}
	function deleterecords($id)
	{
	  $query= $this->db->where("id", $id);
	  $query=$this->db->delete("student");
	  return true;
	}
	function update_records($id)
	{
	$query=$this->db->where('id',$id)->get('student')->row_array();
	return $query;
	}

	
}