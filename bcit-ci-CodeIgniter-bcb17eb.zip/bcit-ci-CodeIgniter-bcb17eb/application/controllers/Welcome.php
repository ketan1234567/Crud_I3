<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load Model*/
		$this->load->model('Crud_model');
	}
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function insert_page()
	{
		$result['data'] = $this->Crud_model->displaydata();
		$this->load->view('insert',$result);
	}
	public function insert()
	{
		$data=array(
			'name' =>$this->input->post('name'),
			 'email' => $this->input->post('email'),
			 'mobile' => $this->input->post('mobile'),
			 'address' => $this->input->post('address'),
			 );
			 $response=$this->Crud_model->saverecords($data);
			if($response==true){
			        echo "Records Saved Successfully";
					
	}

	}
}
