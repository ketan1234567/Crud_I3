<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Crud extends CI_Controller
{
	public function __construct()
	{
		/*call CodeIgniter's default Constructor*/
		parent::__construct();

		/*load database libray manually*/
		$this->load->database();

		/*load Model*/
		$this->load->model('Crud_model');
	}
	/*Insert*/
	public function insert_page()
	{
		$result['data'] = $this->Crud_model->displaydata();
		$this->load->view('insert',$result);
	}
	public function savedata()
	{
		/*load registration view form*/
		//$this->load->view('insert');

		/*Check submit button */
		$name = $_FILES['file']['name'];
		$uploads_dir = 'upload/';
		$tmp_name = $_FILES["file"]["tmp_name"];

		move_uploaded_file($tmp_name, "$uploads_dir/$name");

		$data = array(
			'name' => $this->input->post('name'),
			'email' => $this->input->post('email'),
			'mobile' => $this->input->post('mobile'),
			'address' => $this->input->post('address'),
			'file' => $name

		);
		$response = $this->Crud_model->saverecords($data);
		if ($response == true) {
			redirect('insert');
		}
	}

	public function displaydata()														
	{
	$result['data'] = $this->Crud_model->displaydata();
	//   print_r($result);
   $this->load->view('display_records', $result);
	}

	public function deletedata($id)
	{


		$response = $this->Crud_model->deleterecords($id);
		if ($response == true) {
			redirect('insert');
			
		}
	}
	public function updatedata($id)
	{
	
		$result['data'] = $this->Crud_model->update_records($id);
		//print_r($result);

		$this->load->view('update_records', $result);


		// if ($this->input->post('update')) {
		// 	$name = $this->input->post('name');
		// 	$email = $this->input->post('email');
		// 	$mobile = $this->input->post('mobile');
		// 	$address = $this->input->post('address');
		// 	$this->Crud_model->update_records($name, $email, $mobile, $address);
		// 	echo "Date updated successfully !";
		// }
	}
	public function updtitle() 
{   
	$name = $_FILES['file']['name'];
		$uploads_dir = 'upload/';
		$tmp_name = $_FILES["file"]["tmp_name"];

		move_uploaded_file($tmp_name, "$uploads_dir/$name");
    $data = array(
        'table_name' => 'student', // pass the real table name
        'id' => $this->input->post('id'),
        'name' => $this->input->post('name'),
        'email' => $this->input->post('email'),
		'mobile' => $this->input->post('mobile'),
		'address' => $this->input->post('address'),
		'file' => $name
    );

    $this->load->model('Crud_model'); // load the model first
    if($this->Crud_model->upddata($data)) // call the method from the model
    {
        echo "update successful";
        redirect('insert');
    }
    else
    {
        echo "update not successful";
    }

}
 


	
}
